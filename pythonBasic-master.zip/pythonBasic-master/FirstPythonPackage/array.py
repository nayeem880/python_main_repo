numbers = [5,6,7,89,3,44,2]
friends=["nayem","nishpa","ohi","shuvo","dipu","nishpa"]
print(friends.index("ohi"))
print(friends.count("nishpa"))
print(friends[1])
numbers.sort()
print(numbers)
numbers.reverse()
print(numbers)
numbers2=numbers.copy()
print(numbers2)

#this is a single line comment in python

"""this is a multiline comment in python"""