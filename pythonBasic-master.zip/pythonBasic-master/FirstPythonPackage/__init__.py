from math import *

print("    /|")
print("   / |")
print("  /  |")
print(" /   |")
print("/____|")

character_name="cuckoo"
character_age=35
character_color="blue and golden too"
character_help="and this will help nature to be preserved"

print("they are 30 years old but one of them is: "+str(character_age))
print("they are black and ugly but there are: "+character_color.upper())
print("but adorable to keep them for the nature: "+character_help.upper())

print(character_name)
print(len(character_name))

print(character_name.upper())
print(character_name.index("k"))
print(character_name[2].upper())
print(character_name[2])
print(character_name.upper().index("K"))
print(character_name.replace("cuc","buck"))


print(-20.5579)
print(-20.5579-4)
print(-20.5579+5)
print(-20.5579/4)
print(-20.5579%5)
print(-20.5579*2)

new="hehhehe"
print(new)
absulate=-5

print("this is the age of previous initialization: "+str(character_age))
print(abs(absulate))
print("this is power funtion of 5^2 which is : "+str(pow(5,2)))
print("find out which number is max between 9 and 11, the bigger is : "+str(max(9,11)))
print(round(5.5))
print(floor(7))
print(sqrt(4.5))
print(ceil(6))


inputByUser = input("Enter your name : ")
print("the name inputted by user is "+inputByUser+".Hello !"+inputByUser)

inputnumber1= input("Enter your first number : ")
inputnumber2= input("Enter your second number : ")
result=int(inputnumber1)+int(inputnumber2)
print("Addition of two inputted number is : "+str(result))

result=int(inputnumber1)-int(inputnumber2)
print("subtraction of two inputted number is : "+str(result))
result=int(inputnumber1)*int(inputnumber2)
print("multiple of two inputted number is : "+str(result))
result=int(inputnumber1)/int(inputnumber2)
print("Division of two inputted number is : "+str(float(result)))




