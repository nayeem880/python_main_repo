print("Hello nayeem! Are you coding???")
var =5
var1=4
result=var-var1

print(result)
division=var/var1
times=var*var1
summation=var+var1
subtraction=var+var1
modulus=var%var1
print("Modulus of var and var1 is : "+modulus)
print("var times var1 is : "+times)
print("division of var and var1 is : "+division)
print("subtraction of var and var1 is : "+subtraction)
print("summation of var and var1 is : "+summation)

