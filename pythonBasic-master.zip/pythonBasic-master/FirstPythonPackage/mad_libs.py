color= input("enter a color : ")
plural_noun= input('enter a plural : ')
celebrity= input('enter a celebrity : ')


print("Roses are "+color)
print("plural noun are "+plural_noun)
print("celebrities are "+celebrity)